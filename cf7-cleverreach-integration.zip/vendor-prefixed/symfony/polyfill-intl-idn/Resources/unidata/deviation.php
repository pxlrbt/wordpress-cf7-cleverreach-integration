<?php

namespace pxlrbt\Cf7Cleverreach\Vendor;

return array(223 => 'ss', 962 => 'σ', 8204 => '', 8205 => '');
