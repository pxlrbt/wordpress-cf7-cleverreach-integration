<?php

namespace pxlrbt\Cf7Cleverreach\Vendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
