<?php

namespace pxlrbt\Cf7Cleverreach\Vendor;

// Don't redefine the functions if included multiple times.
if (!\function_exists('pxlrbt\\Cf7Cleverreach\\Vendor\\GuzzleHttp\\Psr7\\str')) {
    require __DIR__ . '/functions.php';
}
