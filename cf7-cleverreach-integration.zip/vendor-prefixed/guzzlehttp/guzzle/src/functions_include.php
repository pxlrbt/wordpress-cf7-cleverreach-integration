<?php

namespace pxlrbt\Cf7Cleverreach\Vendor;

// Don't redefine the functions if included multiple times.
if (!\function_exists('pxlrbt\\Cf7Cleverreach\\Vendor\\GuzzleHttp\\uri_template')) {
    require __DIR__ . '/functions.php';
}
