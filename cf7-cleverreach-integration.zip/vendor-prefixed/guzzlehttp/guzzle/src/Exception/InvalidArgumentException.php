<?php

namespace pxlrbt\Cf7Cleverreach\Vendor\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException
{
}
