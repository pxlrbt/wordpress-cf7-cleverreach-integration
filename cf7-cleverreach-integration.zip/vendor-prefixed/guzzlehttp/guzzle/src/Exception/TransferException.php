<?php

namespace pxlrbt\Cf7Cleverreach\Vendor\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}
