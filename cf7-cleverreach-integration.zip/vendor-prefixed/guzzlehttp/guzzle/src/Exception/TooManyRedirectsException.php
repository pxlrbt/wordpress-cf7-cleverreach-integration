<?php

namespace pxlrbt\Cf7Cleverreach\Vendor\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
