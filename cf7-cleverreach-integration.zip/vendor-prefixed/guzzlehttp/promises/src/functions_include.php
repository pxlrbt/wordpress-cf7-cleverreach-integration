<?php

namespace pxlrbt\Cf7Cleverreach\Vendor;

// Don't redefine the functions if included multiple times.
if (!\function_exists('pxlrbt\\Cf7Cleverreach\\Vendor\\GuzzleHttp\\Promise\\promise_for')) {
    require __DIR__ . '/functions.php';
}
